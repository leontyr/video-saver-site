# Distribution checklist

This custom core is intended to use FFmpeg under LGPL-2.1-or-later, with GPL,
nonfree, and version-3-only components disabled. Verify the exported config.h
and the browser `-version` output before release.

Release pairing: Video Saver 0.7.5 (raw AAC demuxer enabled).

1. Keep COPYING.LGPLv2.1, wrapper MIT notices, and upstream copyright notices.
2. Make the exact corresponding-source package available without extra charge
   alongside each released binary; include this Dockerfile, configure-core.sh, link-core.sh, the
   pinned wrapper source archive, and the generated FFmpeg source archive.
3. Add a stable public source-download URL to THIRD_PARTY_NOTICES.md before
   publishing. A link only to an unrelated upstream version is insufficient.
4. Preserve the independently replaceable ffmpeg-core.js / ffmpeg-core.wasm
   files and document rebuilding/loading an unpacked extension with modified
   versions. Do not require a signature or checksum to run a modified core.
5. Ensure proprietary product terms do not prohibit reverse engineering for
   debugging modifications to LGPL components or exercise of their LGPL rights.
6. The included Emscripten runtime has its own permissive license notices;
   preserve them and the exact toolchain reference.
7. Codec patents, Chrome Web Store policies, and rights to downloaded media are
   separate matters. LGPL licensing does not settle them.

Have your distribution arrangement reviewed if you need legal certainty.
