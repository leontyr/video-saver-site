#!/bin/bash
set -euo pipefail
emconfigure ./configure --target-os=none --arch=x86_32 --enable-cross-compile \
  --disable-asm --disable-stripping --disable-programs --disable-doc \
  --disable-debug --disable-runtime-cpudetect --disable-autodetect \
  --nm=emnm --ar=emar --ranlib=emranlib --cc=emcc --cxx=em++ \
  --objcc=emcc --dep-cc=emcc --extra-cflags=-O3 --extra-cxxflags=-O3 \
  --disable-pthreads --disable-w32threads --disable-os2threads "$@"
