# Minimal LGPL FFmpeg WebAssembly core

Pinned versions: FFmpeg 5.1.4, ffmpeg.wasm wrapper v0.12.10
(c3a763857c5e615ae8674715ad5e4f63ff469e9d), Emscripten 3.1.40.

Build from this directory:

```
docker build --platform linux/amd64 --output type=local,dest=dist .
```

The build explicitly disables GPL, nonfree, version-3-only features, external
codec libraries, and network protocols. It enables local HLS/MPEG-TS/fMP4 input,
raw AAC input, MP4 output, stream-copy support, and H.264/HEVC/AAC parsing and probing.
No video or audio encoders are enabled. Decryption occurs in the extension.

Video Saver 0.7.5 adds the LGPL raw AAC demuxer. Separate HLS audio can be
ADTS AAC rather than MPEG-TS or fMP4 even if a local segment filename ends in
`.ts`. Enabling the AAC parser alone does not enable the AAC demuxer. The
browser regression includes all three cases (master selection, explicit fMP4
audio, explicit raw ADTS AAC audio) using the actual packaged converter.
Current results are recorded in `browser-verification-v0.7.5.json`; the older
`browser-verification.json` records the earlier 0.7.0 full-episode checks.

The generated configuration is checked before linking. The output includes
configuration files, the LGPL 2.1 license, and a corresponding-source archive.
Compilation is limited to four jobs to avoid exhausting Docker memory.
Publish these sources and this build recipe alongside any distributed binaries.
Recipients must be able to replace the LGPL component with a modified build;
do not impose license terms forbidding that replacement or debugging it.

This recipe is not a legal compliance opinion. Review final distribution terms.
